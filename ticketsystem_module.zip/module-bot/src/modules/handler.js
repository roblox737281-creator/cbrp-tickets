const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const { createLogger } = require('../logger');
async function loadModulesFromDir(params) {
  const loaderLogger = params.logger ?? createLogger('modules');
  if (!fs.existsSync(params.dir)) return [];
  const entries = fs.readdirSync(params.dir, { withFileTypes: true });
  const files = entries
    .filter((e) => e.isFile())
    .map((e) => e.name)
    .filter((name) => !name.startsWith('_'))
    .filter((name) => name.endsWith('.js') || name.endsWith('.cjs'));
  const req = createRequire(__filename);
  const modules = [];
  for (const file of files) {
    const fullPath = path.resolve(params.dir, file);
    try {
      const loaded = req(fullPath);
      const candidate = loaded?.default ?? loaded?.module ?? loaded;
      if (!candidate || typeof candidate !== 'object') continue;
      if (typeof candidate.id !== 'string' || typeof candidate.init !== 'function') continue;
      modules.push(candidate);
    } catch (err) {
      loaderLogger.warn(`Failed loading module file ${file}: ${err?.message || String(err)}`);
    }
  }
  return modules;
}
async function initModules(params) {
  const fallbackLogger = params.logger ?? createLogger('modules');
  const active = [];
  const listeners = [];
  for (const mod of params.modules) {
    const modLogger = createLogger(mod.id);
    const isEnabled = mod.enabled ? mod.enabled({ logger: modLogger }) : true;
    if (!isEnabled) continue;
    const runtime = await mod.init({
      client: params.client,
      logger: modLogger,
    });
    active.push({ module: mod, runtime });
  }
  for (const row of active) {
    const events = row.runtime.events;
    if (!events) continue;
    for (const [event, fn] of Object.entries(events)) {
      if (typeof fn !== 'function') continue;
      const wrapped = (...args) => fn(...args);
      params.client.on(event, wrapped);
      listeners.push({ event, fn: wrapped });
    }
  }
  return {
    stop: async () => {
      for (const l of listeners) {
        params.client.off(l.event, l.fn);
      }
      await Promise.all(active.map(async (row) => await row.runtime.stop?.()));
    },
    modules: active.map((a) => a.module.id),
    activeModules: active.map((a) => a.module),
  };
}

module.exports = { loadModulesFromDir, initModules };
