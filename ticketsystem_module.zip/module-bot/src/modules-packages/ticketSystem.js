const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ComponentType,
  EmbedBuilder,
  GuildMember,
  MessageFlags,
  ModalBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
  TextInputStyle,
} = require('discord.js');
const { env } = require('../env');
const { getMongoDb } = require('../utils/mongo');
const dock = require('../utils/dock');
const melonly = require('../utils/melonly');

const TICKET_DROPDOWN_CUSTOM_ID = 'ticketsystem:dropdown';
const TICKET_MODAL_CUSTOM_ID_PREFIX = 'ticketsystem:modal:';
const TICKET_INQUIRY_INPUT_ID = 'ticketsystem:inquiry';
const TICKET_CLAIM_BUTTON_ID = 'ticketsystem:claim';
const TICKET_UNCLAIM_BUTTON_ID = 'ticketsystem:unclaim';
const TICKET_CLOSE_BUTTON_ID = 'ticketsystem:close';
const TICKET_CLOSE_MODAL_ID = 'ticketsystem:closeModal';
const TICKET_CLOSE_REASON_INPUT_ID = 'ticketsystem:closeReason';
const TICKET_CLOSE_REQUEST_ACCEPT_BUTTON_ID = 'ticketsystem:closeRequest:accept';
const TICKET_CLOSE_REQUEST_DENY_BUTTON_ID = 'ticketsystem:closeRequest:deny';
const TICKET_TRANSCRIPT_REQUEST_BUTTON_PREFIX = 'ticketsystem:transcript:';

const config = {
  enabled: false, // Status of module
  accountLinkProvider: 'dock', // "melonly" or "dock" for Roblox info on the ticket opener
  ticketsCollectionName: 'ticketsystem_tickets', // Mongo collection for ticket records
  countersCollectionName: 'ticketsystem_counters', // Mongo collection for per-guild ticket counters
  transcriptDeleteDelayMs: 3_000, // Delay before deleting a closed ticket channel (ms)
  transcriptButtonLabel: 'Transcript', // Button label used when linking a transcript
  transcriptRequestButtonLabel: 'View Transcript', // Button label used in transcript logs
  transcriptButtonEmoji: { id: '1497180059306557490', name: 'erlcpackages_Ticket' }, // Optional emoji used on transcript buttons
  defaultBrandHeader: '<:erlcpackages:1505526220085924011> |', // Header prefix used in ticket and log containers
  defaultPanelWelcomeText:
    'Welcome to the support menu. If you have any questions, concerns, or need help within our community, you may open a support ticket to get in touch with a member of our staff team. Please select the correct ticket type before submitting.',
  defaultOpenBodyText:
    'Our staff team has been notified; and they will review your ticket shortly. In the mean time, please provide **any additional details** to help us resolve your issue.\n\n:warning: **Please do __NOT__ ping staff, as they have already been notified.**',
  guilds: {
    '1477472774070079540': {
      dropdownPlaceholder: 'Request Assistance',
      panelMessageTitle: 'Support',
      panelMessageDescription: '.',
      panelWelcomeText:
        '> Welcome to the **Example Server** Support Menu. If you need help, you may open a support ticket to get in touch with a staff member. Please select the correct ticket type before submitting.',
      panelCategoriesText:
        '## General Support:\n' +
        '> -# Use this ticket for normal support questions, help requests, or player issues.\n' +
        '## Staff Support:\n' +
        '> -# Use this ticket for escalated concerns, staff-related reports, or management review.',
      panelTopBannerUrl: 'https://media.discordapp.net/attachments/1496912052139069570/1505488841228812288/image.png?ex=6a3aedfe&is=6a399c7e&hm=8eeb851e9fe31a34004ed2031f9d90ebacc889879c6b0ad7a512e2e292041db7&=&format=webp&quality=lossless&width=3589&height=1119',
      panelBottomBannerUrl: 'https://cdn.discordapp.com/attachments/1496912052139069570/1505488870798786570/image.png?ex=6a3aee05&is=6a399c85&hm=554723307ace1c7cb304b6913a9e9c72cc5d18e0bda710b886248bc545e56d68&',
      assistanceChannelId: '1518603920417488926',
      channelNameTemplate: 'ticket-{panel}-{number}',
      transcriptLogChannelId: '1518718545847128205',
      brandHeader: '<:erlcpackages:1505526220085924011> |',
      panels: [
        {
          key: 'general_support',
          name: 'General Support',
          channelSlug: 'gen',
          roleIds: ['1496841613807321149'],
          categoryId: '1518718629816827955',
          openable: true,
          topBannerUrl: 'https://media.discordapp.net/attachments/1496912052139069570/1505488841228812288/image.png?ex=6a3aedfe&is=6a399c7e&hm=8eeb851e9fe31a34004ed2031f9d90ebacc889879c6b0ad7a512e2e292041db7&=&format=webp&quality=lossless&width=3589&height=1119',
          bottomBannerUrl: 'https://cdn.discordapp.com/attachments/1496912052139069570/1505488870798786570/image.png?ex=6a3aee05&is=6a399c85&hm=554723307ace1c7cb304b6913a9e9c72cc5d18e0bda710b886248bc545e56d68&',
        },
        {
          key: 'hr_support',
          name: 'High Rank Support',
          channelSlug: 'staff',
          roleIds: ['1496841595255783537'],
          categoryId: '1518718667947376840',
          openable: true,
          topBannerUrl: 'https://media.discordapp.net/attachments/1496912052139069570/1505488841228812288/image.png?ex=6a3aedfe&is=6a399c7e&hm=8eeb851e9fe31a34004ed2031f9d90ebacc889879c6b0ad7a512e2e292041db7&=&format=webp&quality=lossless&width=3589&height=1119',
          bottomBannerUrl: 'https://cdn.discordapp.com/attachments/1496912052139069570/1505488870798786570/image.png?ex=6a3aee05&is=6a399c85&hm=554723307ace1c7cb304b6913a9e9c72cc5d18e0bda710b886248bc545e56d68&',
        },
      ],
    },
  },
};

let ticketsCollectionPromise = null;
let countersCollectionPromise = null;

function getTicketGuildConfig(guildId) {
  return config.guilds[guildId] ?? null;
}

function getTicketPanelsInOrder(guildId) {
  const guildConfig = getTicketGuildConfig(guildId);
  return Array.isArray(guildConfig?.panels) ? guildConfig.panels : [];
}

function getTicketPanelByKey(guildId, key) {
  return getTicketPanelsInOrder(guildId).find((panel) => panel.key === key) ?? null;
}

function getAllowedTicketCommandRoleIds(guildId) {
  return [...new Set(getTicketPanelsInOrder(guildId).flatMap((panel) => panel.roleIds || []).filter(Boolean))];
}

function getVisibleSupportRoleIdsForPanel(guildId, panelKey) {
  const panels = getTicketPanelsInOrder(guildId);
  const index = panels.findIndex((panel) => panel.key === panelKey);
  if (index < 0) return [];
  return [...new Set(panels.slice(index).flatMap((panel) => panel.roleIds || []).filter(Boolean))];
}

async function getTicketsCollection() {
  if (!ticketsCollectionPromise) {
    ticketsCollectionPromise = (async () => {
      const db = await getMongoDb();
      const collection = db.collection(config.ticketsCollectionName);
      await collection.createIndex({ guildId: 1, channelId: 1 }, { unique: true }).catch(() => null);
      await collection.createIndex({ guildId: 1, userId: 1, status: 1 }).catch(() => null);
      await collection.createIndex({ guildId: 1, ticketNumber: 1 }, { unique: true }).catch(() => null);
      return collection;
    })();
  }
  return ticketsCollectionPromise;
}

async function getCountersCollection() {
  if (!countersCollectionPromise) {
    countersCollectionPromise = (async () => {
      const db = await getMongoDb();
      const collection = db.collection(config.countersCollectionName);
      await collection.createIndex({ guildId: 1 }, { unique: true }).catch(() => null);
      return collection;
    })();
  }
  return countersCollectionPromise;
}

async function getNextTicketNumber(guildId) {
  const counters = await getCountersCollection();
  const doc = await counters.findOneAndUpdate(
    { guildId },
    { $inc: { nextTicketNumber: 1 } },
    { upsert: true, returnDocument: 'after' },
  );
  return doc?.nextTicketNumber ?? 1;
}

function formatTimestamp(ms, style = 'F') {
  return `<t:${Math.floor(ms / 1000)}:${style}>`;
}

function getBrandHeader(guildId) {
  const guildConfig = getTicketGuildConfig(guildId);
  return guildConfig?.brandHeader?.trim() || config.defaultBrandHeader;
}

function getTicketButtonEmoji() {
  if (!config.transcriptButtonEmoji?.id && !config.transcriptButtonEmoji?.name) return null;
  return {
    ...(config.transcriptButtonEmoji.id ? { id: config.transcriptButtonEmoji.id } : {}),
    ...(config.transcriptButtonEmoji.name ? { name: config.transcriptButtonEmoji.name } : {}),
  };
}

function buildTranscriptLinkRow(transcriptUrl) {
  const button = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(transcriptUrl).setLabel(config.transcriptButtonLabel);
  const emoji = getTicketButtonEmoji();
  if (emoji) button.setEmoji(emoji);
  return new ActionRowBuilder().addComponents(button);
}

function buildTranscriptRequestRow(ticketChannelId) {
  const button = new ButtonBuilder()
    .setCustomId(`${TICKET_TRANSCRIPT_REQUEST_BUTTON_PREFIX}${ticketChannelId}`)
    .setStyle(ButtonStyle.Secondary)
    .setLabel(config.transcriptRequestButtonLabel);
  const emoji = getTicketButtonEmoji();
  if (emoji) button.setEmoji(emoji);
  return new ActionRowBuilder().addComponents(button);
}

function memberCanUseTicketCommands(member, guildId) {
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  const allowedRoleIds = getAllowedTicketCommandRoleIds(guildId);
  return allowedRoleIds.some((roleId) => member.roles.cache.has(roleId));
}

function memberCanViewTranscript(params) {
  const { member, ticket } = params;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (member.id === ticket.userId) return true;
  if (Array.isArray(ticket.extraMemberIds) && ticket.extraMemberIds.includes(member.id)) return true;
  if (Array.isArray(ticket.extraRoleIds) && ticket.extraRoleIds.some((roleId) => member.roles.cache.has(roleId))) return true;
  const visibleSupportRoleIds = getVisibleSupportRoleIdsForPanel(ticket.guildId, ticket.panelKey);
  return visibleSupportRoleIds.some((roleId) => member.roles.cache.has(roleId));
}

function renderChannelName(template, params) {
  const safeUsername = String(params.username || '').toLowerCase().replace(/[^a-z0-9-_]/g, '-');
  const safePanel = String(params.panel || '').toLowerCase().replace(/[^a-z0-9-_]/g, '-');
  return String(template || 'ticket-{panel}-{number}')
    .split('{username}')
    .join(safeUsername)
    .split('{panel}')
    .join(safePanel)
    .split('{number}')
    .join(String(params.number))
    .slice(0, 90);
}

function buildOpenButtons() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(TICKET_CLAIM_BUTTON_ID).setLabel('Claim').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(TICKET_CLOSE_BUTTON_ID).setLabel('Close').setStyle(ButtonStyle.Danger),
  );
}

function buildClaimedButtons() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(TICKET_UNCLAIM_BUTTON_ID).setLabel('Unclaim').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(TICKET_CLOSE_BUTTON_ID).setLabel('Close').setStyle(ButtonStyle.Danger),
  );
}

function getContainersFromMessageComponents(components) {
  if (!Array.isArray(components)) return [];
  return components.filter((component) => component && typeof component === 'object' && component.type === 17);
}

async function createCookieTranscript(params) {
  if (!env.cookieApiKey) {
    return { ok: false, error: 'COOKIE_API_KEY is not set.' };
  }
  if (!env.discordToken) {
    return { ok: false, error: 'DISCORD_TOKEN is not set.' };
  }

  const url = `https://api.cookie-api.com/api/transcript?channel_id=${encodeURIComponent(params.channelId)}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: env.cookieApiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ bot_token: env.discordToken }),
  }).catch(() => null);

  if (!res) return { ok: false, error: 'Transcript request failed (network error).' };

  const data = await res.json().catch(() => null);
  const transcriptUrl = data?.url;
  if (!res.ok || !data?.success || !transcriptUrl) {
    const message = data?.message ? String(data.message) : `HTTP ${res.status}`;
    return { ok: false, error: message };
  }

  return { ok: true, url: transcriptUrl };
}

async function resolveRobloxIdForDiscordId(params) {
  if (config.accountLinkProvider === 'dock') {
    return await dock
      .getRobloxIdForDiscordIdDock({
        discordId: params.discordId,
        guildId: params.guildId,
        apiKey: env.dockApiKey,
      })
      .catch(() => null);
  }

  return await melonly
    .getRobloxIdForDiscordId({
      discordId: params.discordId,
      apiKey: env.melonlyApiKey,
    })
    .catch(() => null);
}

async function getRobloxProfileForDiscordId(params) {
  const robloxId = await resolveRobloxIdForDiscordId(params);
  if (!robloxId) return { robloxId: null, username: null, ageDays: null };

  const res = await fetch(`https://users.roblox.com/v1/users/${robloxId}`).catch(() => null);
  const data = res && res.ok ? await res.json().catch(() => null) : null;
  const username = typeof data?.name === 'string' ? data.name : null;
  let ageDays = null;
  if (typeof data?.created === 'string') {
    const createdAt = new Date(data.created);
    if (!Number.isNaN(createdAt.getTime())) {
      ageDays = Math.floor((Date.now() - createdAt.getTime()) / 86_400_000);
    }
  }
  return { robloxId, username, ageDays };
}

function buildPermissionOverwrites(params) {
  return [
    { id: params.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: params.ticket.userId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
      ],
    },
    ...(params.visibleSupportRoleIds || []).map((roleId) => ({
      id: roleId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
      ],
    })),
    ...((params.ticket.extraRoleIds || []).map((roleId) => ({
      id: roleId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
      ],
    })) || []),
    ...((params.ticket.extraMemberIds || []).map((memberId) => ({
      id: memberId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
      ],
    })) || []),
  ];
}

async function closeTicketByChannel(params) {
  const guildConfig = getTicketGuildConfig(params.guildId);
  if (!guildConfig) return { ok: false, error: 'Ticket system is not enabled in this server.' };

  const tickets = await getTicketsCollection();
  const ticket = await tickets.findOne({ guildId: params.guildId, channelId: params.channelId });
  if (!ticket) return { ok: false, error: 'Ticket not found in the database.' };

  const closedAt = Date.now();
  const transcript = await createCookieTranscript({ channelId: params.channelId });

  await tickets
    .updateOne(
      { guildId: params.guildId, channelId: params.channelId },
      {
        $set: {
          status: 'closed',
          closedBy: params.closedByUserId,
          closeReason: params.closeReason,
          closedAt,
          ...(transcript.ok ? { transcriptUrl: transcript.url } : {}),
        },
        $unset: { closeRequest: '' },
      },
    )
    .catch(() => null);

  const panel = getTicketPanelByKey(params.guildId, ticket.panelKey);
  const topBannerUrl = panel?.topBannerUrl ?? '';
  const bottomBannerUrl = panel?.bottomBannerUrl ?? '';
  const brandHeader = getBrandHeader(params.guildId);
  const openedAt = ticket.openedAt ?? Date.now();
  const claimedByText = ticket.claimedBy ? `<@${ticket.claimedBy}>` : 'Not Claimed';

  const dmOpenedBlock = [
    `> **Opened By:** <@${ticket.userId}>`,
    `> **Claimed By:** ${claimedByText}`,
    `> **Ticket Panel:** ${ticket.panelName}`,
    `> **Opened At:** ${formatTimestamp(openedAt, 'F')}`,
  ].join('\n');
  const dmClosedBlock = [
    `> **Closed By:** <@${params.closedByUserId}>`,
    `> **Closed At:** ${formatTimestamp(closedAt, 'F')}`,
    `> **Close Reason:** ${params.closeReason}`,
  ].join('\n');

  const dmTopContainer = {
    type: 17,
    components: [
      ...(topBannerUrl ? [{ type: 12, items: [{ media: { url: topBannerUrl } }] }] : []),
      { type: 14, spacing: 1, divider: true },
      { type: 10, content: `# ${brandHeader} Ticket Transcript` },
      { type: 14, spacing: 1, divider: true },
      { type: 10, content: dmOpenedBlock },
      { type: 14, spacing: 1, divider: true },
      { type: 10, content: dmClosedBlock },
    ],
  };
  const dmBottomContainer = bottomBannerUrl
    ? { type: 17, components: [{ type: 12, items: [{ media: { url: bottomBannerUrl } }] }] }
    : null;

  const dmUser = await params.client.users.fetch(ticket.userId).catch(() => null);
  let dmFallbackUsed = false;
  let dmSendErrorText = null;
  if (dmUser) {
    let sent = false;
    try {
      const components = [dmTopContainer];
      if (dmBottomContainer) components.push(dmBottomContainer);
      if (transcript.ok) components.push(buildTranscriptLinkRow(transcript.url).toJSON());
      await dmUser.send({ components, flags: MessageFlags.IsComponentsV2 });
      sent = true;
    } catch (err) {
      const code = err?.code ? String(err.code) : null;
      const message = err?.message ? String(err.message) : null;
      dmSendErrorText = [code, message].filter(Boolean).join(' - ').slice(0, 900) || 'Unknown error';
    }

    if (!sent) {
      dmFallbackUsed = true;
      const content = transcript.ok
        ? `Your ticket was closed. Transcript: ${transcript.url}`
        : 'Your ticket was closed. Transcript was unavailable.';
      await dmUser.send({ content, allowedMentions: { parse: [] } }).catch(() => null);
    }
  }

  const logChannel = guildConfig.transcriptLogChannelId
    ? await params.client.channels.fetch(guildConfig.transcriptLogChannelId).catch(() => null)
    : null;

  if (logChannel && logChannel.isTextBased()) {
    if (dmFallbackUsed) {
      const embed = new EmbedBuilder()
        .setTitle('Transcript DM Fallback')
        .setColor('#242429')
        .addFields(
          { name: 'Ticket Channel', value: `<#${params.channelId}>`, inline: true },
          { name: 'Opened By', value: `<@${ticket.userId}>`, inline: true },
          { name: 'Reason', value: dmSendErrorText ?? 'Unknown error', inline: false },
        )
        .setTimestamp();
      await logChannel.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => null);
    }

    const logOpenedBlock = [
      `> **Opened By:** <@${ticket.userId}>`,
      `> **Claimed By:** ${claimedByText}`,
      `> **Ticket Panel:** ${ticket.panelName}`,
      `> **Opened At:** ${formatTimestamp(openedAt, 'F')}`,
    ].join('\n');
    const logClosedBlock = [
      `> **Closed By:** <@${params.closedByUserId}>`,
      `> **Closed At:** ${formatTimestamp(closedAt, 'F')}`,
      `> **Close Reason:** ${params.closeReason}`,
    ].join('\n');

    const logContainer = {
      type: 17,
      components: [
        { type: 10, content: `# ${brandHeader} Ticket Log` },
        { type: 14, spacing: 1, divider: true },
        { type: 10, content: logOpenedBlock },
        { type: 14, spacing: 1, divider: true },
        { type: 10, content: logClosedBlock },
      ],
    };
    if (transcript.ok) {
      logContainer.components.push(
        { type: 14, spacing: 1, divider: true },
        buildTranscriptRequestRow(params.channelId).toJSON(),
      );
    }
    await logChannel
      .send({
        components: [logContainer],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
  }

  const guild = await params.client.guilds.fetch(params.guildId).catch(() => null);
  const channel = guild ? await guild.channels.fetch(params.channelId).catch(() => null) : null;
  if (channel && channel.type === ChannelType.GuildText) {
    setTimeout(() => {
      channel.delete().catch(() => null);
    }, Math.max(0, config.transcriptDeleteDelayMs));
  }

  return { ok: true, transcriptUrl: transcript.ok ? transcript.url : null };
}

function buildPanelSlash() {
  return new SlashCommandBuilder()
    .setName('ticketpanel')
    .setDescription('Send the ticket panel (dropdown) to a channel.')
    .addChannelOption((option) =>
      option
        .setName('channel')
        .setDescription('Channel to send the panel in (defaults to current channel)')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false),
    )
    .setDefaultMemberPermissions(null)
    .toJSON();
}

const sharedSlashCommands = [
  new SlashCommandBuilder()
    .setName('add')
    .setDescription('Allows a user or role to access the current ticket.')
    .addUserOption((option) => option.setName('user').setDescription('User to add').setRequired(false))
    .addRoleOption((option) => option.setName('role').setDescription('Role to add').setRequired(false))
    .setDefaultMemberPermissions(null),
  new SlashCommandBuilder().setName('claim').setDescription('Claim the current ticket.').setDefaultMemberPermissions(null),
  new SlashCommandBuilder()
    .setName('close')
    .setDescription('Closes the current ticket.')
    .addStringOption((option) =>
      option.setName('reason').setDescription('Reason for closing the ticket').setRequired(true).setMaxLength(1000),
    )
    .setDefaultMemberPermissions(null),
  new SlashCommandBuilder()
    .setName('closerequest')
    .setDescription('Send a close request to the ticket opener.')
    .addStringOption((option) =>
      option
        .setName('reason')
        .setDescription('Reason for requesting ticket closure')
        .setRequired(true)
        .setMaxLength(1000),
    )
    .setDefaultMemberPermissions(null),
  new SlashCommandBuilder()
    .setName('remove')
    .setDescription('Removes a user or role from the current ticket.')
    .addUserOption((option) => option.setName('user').setDescription('User to remove').setRequired(false))
    .addRoleOption((option) => option.setName('role').setDescription('Role to remove').setRequired(false))
    .setDefaultMemberPermissions(null),
  new SlashCommandBuilder()
    .setName('rename')
    .setDescription('Renames the current ticket channel.')
    .addStringOption((option) =>
      option.setName('name').setDescription('New channel name').setRequired(true).setMinLength(1).setMaxLength(90),
    )
    .setDefaultMemberPermissions(null),
  new SlashCommandBuilder()
    .setName('switchpanel')
    .setDescription('Switch the current ticket to a different panel (category & permissions).')
    .addStringOption((option) =>
      option.setName('panel').setDescription('Panel to switch to').setRequired(true).setAutocomplete(true),
    )
    .setDefaultMemberPermissions(null),
  new SlashCommandBuilder().setName('unclaim').setDescription('Unclaim the current ticket.').setDefaultMemberPermissions(null),
];

function buildSlashCommands() {
  return Object.keys(config.guilds).flatMap((guildId) => [
    { guildId, definition: buildPanelSlash(guildId) },
    ...sharedSlashCommands.map((command) => ({ guildId, definition: command.toJSON() })),
  ]);
}

async function updateOpenMessageButtons(channel, openMessageId, buttonsBuilder) {
  if (!openMessageId) return;
  const message = await channel.messages.fetch(openMessageId).catch(() => null);
  if (!message) return;
  const containers = getContainersFromMessageComponents(message.components);
  await message
    .edit({
      components: [...containers, buttonsBuilder.toJSON()],
      flags: MessageFlags.IsComponentsV2,
    })
    .catch(() => null);
}

async function handleTicketPanelCommand(interaction) {
  if (!interaction.inGuild() || !interaction.guild || !(interaction.member instanceof GuildMember)) return;
  const guildConfig = getTicketGuildConfig(interaction.guild.id);
  if (!guildConfig) {
    await interaction.reply({ content: 'Ticket system is not enabled in this server.', flags: 64 }).catch(() => null);
    return;
  }
  if (!memberCanUseTicketCommands(interaction.member, interaction.guild.id)) {
    await interaction.reply({ content: 'You do not have permission to send the ticket panel.', flags: 64 }).catch(() => null);
    return;
  }

  const preferred =
    interaction.options.getChannel('channel', false) ??
    (guildConfig.assistanceChannelId ? await interaction.guild.channels.fetch(guildConfig.assistanceChannelId).catch(() => null) : null) ??
    interaction.channel;
  if (!preferred || preferred.type !== ChannelType.GuildText) {
    await interaction.reply({ content: 'Invalid channel.', flags: 64 }).catch(() => null);
    return;
  }

  const openablePanels = (guildConfig.panels || []).filter((panel) => panel.openable);
  if (!openablePanels.length) {
    await interaction.reply({ content: 'No ticket panels are currently openable in this server.', flags: 64 }).catch(() => null);
    return;
  }

  const dropdown = new StringSelectMenuBuilder()
    .setCustomId(TICKET_DROPDOWN_CUSTOM_ID)
    .setPlaceholder(guildConfig.dropdownPlaceholder || 'Request Assistance')
    .addOptions(openablePanels.map((panel) => ({ label: panel.name, value: panel.key })));
  const row = new ActionRowBuilder().addComponents(dropdown);

  const welcomeBlock = guildConfig.panelWelcomeText?.trim() || `> ${config.defaultPanelWelcomeText}`;
  const categoriesBlock =
    guildConfig.panelCategoriesText?.trim() ||
    openablePanels
      .map(
        (panel) =>
          `## ${panel.name}:\n> -# Open this ticket to reach the staff team responsible for **${panel.name.toLowerCase()}** requests.`,
      )
      .join('\n');
  const titleLine = `# ${getBrandHeader(interaction.guild.id)} ${guildConfig.panelMessageTitle || `${interaction.guild.name} Support`}`;
  const descriptionLine = guildConfig.panelMessageDescription?.trim() && guildConfig.panelMessageDescription.trim() !== '.'
    ? `${guildConfig.panelMessageDescription.trim()}\n`
    : '';

  const container = {
    type: 17,
    components: [
      ...(guildConfig.panelTopBannerUrl ? [{ type: 12, items: [{ media: { url: guildConfig.panelTopBannerUrl } }] }] : []),
      { type: 14, spacing: 1, divider: true },
      { type: 10, content: `${titleLine}\n${descriptionLine}${welcomeBlock}`.trim() },
      { type: 14, spacing: 1, divider: true },
      { type: 10, content: categoriesBlock },
      { type: 14, spacing: 1, divider: true },
      row.toJSON(),
      ...(guildConfig.panelBottomBannerUrl
        ? [{ type: 14, spacing: 1, divider: true }, { type: 12, items: [{ media: { url: guildConfig.panelBottomBannerUrl } }] }]
        : []),
    ],
  };

  await preferred.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => null);
  await interaction.reply({ content: 'Ticket panel sent.', flags: 64 }).catch(() => null);
}

async function handleSelect(interaction) {
  if (interaction.customId !== TICKET_DROPDOWN_CUSTOM_ID) return false;
  if (!interaction.guildId) return true;

  const guildConfig = getTicketGuildConfig(interaction.guildId);
  if (!guildConfig) {
    await interaction.reply({ content: 'Ticket system is not enabled in this server.', flags: 64 }).catch(() => null);
    return true;
  }

  const panelKey = interaction.values[0];
  const panel = getTicketPanelByKey(interaction.guildId, panelKey);
  if (!panel) {
    await interaction.reply({ content: 'Invalid ticket type selected.', flags: 64 }).catch(() => null);
    return true;
  }

  const modal = ModalBuilder.from({
    custom_id: `${TICKET_MODAL_CUSTOM_ID_PREFIX}${panel.key}`,
    title: `${panel.name} Ticket Inquiry`,
    components: [
      {
        type: ComponentType.Label,
        label: 'Inquiry',
        component: {
          type: ComponentType.TextInput,
          custom_id: TICKET_INQUIRY_INPUT_ID,
          style: TextInputStyle.Paragraph,
          placeholder: 'Describe why you are opening this ticket.',
          required: true,
        },
      },
    ],
  });
  await interaction.showModal(modal).catch(() => null);
  return true;
}

async function handleTicketCreateModal(interaction) {
  if (!interaction.guild || !(interaction.member instanceof GuildMember)) return false;
  if (!interaction.customId.startsWith(TICKET_MODAL_CUSTOM_ID_PREFIX)) return false;

  const guildConfig = getTicketGuildConfig(interaction.guild.id);
  if (!guildConfig) return false;

  const panelKey = interaction.customId.slice(TICKET_MODAL_CUSTOM_ID_PREFIX.length);
  const panel = getTicketPanelByKey(interaction.guild.id, panelKey);
  if (!panel) {
    await interaction.reply({ content: 'Invalid ticket type.', flags: 64 }).catch(() => null);
    return true;
  }

  const inquiry = interaction.fields.getTextInputValue(TICKET_INQUIRY_INPUT_ID).trim();
  await interaction.deferReply({ flags: 64 }).catch(() => null);

  const category = await interaction.guild.channels.fetch(panel.categoryId).catch(() => null);
  if (!category || category.type !== ChannelType.GuildCategory) {
    await interaction.editReply({ content: 'Ticket category is invalid or missing.' }).catch(() => null);
    return true;
  }

  const ticketNumber = await getNextTicketNumber(interaction.guild.id);
  const visibleSupportRoleIds = getVisibleSupportRoleIdsForPanel(interaction.guild.id, panel.key);
  const channelName = renderChannelName(guildConfig.channelNameTemplate, {
    username: interaction.user.username,
    number: ticketNumber,
    panel: panel.channelSlug,
  });

  const channel = await interaction.guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: category.id,
    permissionOverwrites: buildPermissionOverwrites({
      guild: interaction.guild,
      ticket: { userId: interaction.user.id, extraMemberIds: [], extraRoleIds: [] },
      visibleSupportRoleIds,
    }),
  });

  const robloxProfile = await getRobloxProfileForDiscordId({
    discordId: interaction.user.id,
    guildId: interaction.guild.id,
  }).catch(() => ({ robloxId: null, username: null, ageDays: null }));

  const openedAt = Date.now();
  const metaBlock = [
    `> **Ticket ID:** ${ticketNumber}`,
    `> **Date Opened:** ${formatTimestamp(openedAt, 'F')}`,
    `> **Discord User:** ${interaction.user.tag}`,
    `> **Discord ID:** ${interaction.user.id}`,
    `> **Roblox User:** ${robloxProfile.username ?? 'Not linked'}`,
    `> **Roblox ID:** ${robloxProfile.robloxId ? String(robloxProfile.robloxId) : 'N/A'}`,
  ].join('\n');
  const bodyBlock = [
    `> Hello ${interaction.user.username}, thank you for reaching out and opening a ${panel.name} Ticket.`,
    `> `,
    ...String(config.defaultOpenBodyText).split('\n').map((line) => `> ${line}`),
  ].join('\n');
  const reasonBlock = ['## Reason for Ticket:', `> ${inquiry}`].join('\n');
  const roleMentions = (panel.roleIds || []).filter(Boolean).map((roleId) => `<@&${roleId}>`);
  const mentionLine = [interaction.user.toString(), ...roleMentions].join(' | ');

  const ticketContainer = {
    type: 17,
    components: [
      ...(panel.topBannerUrl ? [{ type: 12, items: [{ media: { url: panel.topBannerUrl } }] }] : []),
      { type: 14, spacing: 1, divider: true },
      { type: 10, content: mentionLine },
      { type: 14, spacing: 1, divider: true },
      { type: 10, content: metaBlock },
      { type: 14, spacing: 1, divider: true },
      { type: 10, content: bodyBlock },
      { type: 14, spacing: 1, divider: true },
      { type: 10, content: reasonBlock },
      ...(panel.bottomBannerUrl
        ? [{ type: 14, spacing: 1, divider: true }, { type: 12, items: [{ media: { url: panel.bottomBannerUrl } }] }]
        : []),
    ],
  };

  const ticketMessage = await channel.send({
    components: [ticketContainer, buildOpenButtons().toJSON()],
    flags: MessageFlags.IsComponentsV2,
    allowedMentions: { parse: ['users', 'roles'] },
  });

  const tickets = await getTicketsCollection();
  await tickets
    .insertOne({
      guildId: interaction.guild.id,
      channelId: channel.id,
      openMessageId: ticketMessage.id,
      userId: interaction.user.id,
      username: interaction.user.username,
      ticketNumber,
      panelKey: panel.key,
      panelName: panel.name,
      status: 'open',
      openedAt,
      openReason: inquiry,
      claimedBy: null,
      claimStatus: 'unclaimed',
      extraMemberIds: [],
      extraRoleIds: [],
      closedBy: null,
      closeReason: 'Not Provided',
    })
    .catch(() => null);

  await interaction.editReply({ content: `Your **${panel.name}** ticket has been created — <#${channel.id}>` }).catch(() => null);
  return true;
}

async function handleCloseModal(interaction) {
  if (!interaction.guild || !(interaction.member instanceof GuildMember)) return false;
  if (interaction.customId !== TICKET_CLOSE_MODAL_ID) return false;

  if (!memberCanUseTicketCommands(interaction.member, interaction.guild.id)) {
    await interaction.reply({ content: 'You do not have permission to close tickets.', flags: 64 }).catch(() => null);
    return true;
  }

  const channel = interaction.channel;
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: 'This modal must be used inside a ticket channel.', flags: 64 }).catch(() => null);
    return true;
  }

  const closeReason = interaction.fields.getTextInputValue(TICKET_CLOSE_REASON_INPUT_ID).trim() || 'No reason provided.';
  await interaction.deferReply({}).catch(() => null);
  await interaction.editReply({ content: 'Closing this ticket...' }).catch(() => null);
  const result = await closeTicketByChannel({
    guildId: interaction.guild.id,
    channelId: channel.id,
    closedByUserId: interaction.user.id,
    closeReason,
    client: interaction.client,
  });
  if (!result.ok) {
    await interaction.editReply({ content: `Failed to close ticket: ${result.error}` }).catch(() => null);
  }
  return true;
}

async function handleSwitchPanelAutocomplete(interaction) {
  if (!interaction.inGuild() || !interaction.guild) {
    await interaction.respond([]).catch(() => null);
    return true;
  }

  const guildConfig = getTicketGuildConfig(interaction.guild.id);
  if (!guildConfig) {
    await interaction.respond([]).catch(() => null);
    return true;
  }

  const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  if (!member || !memberCanUseTicketCommands(member, interaction.guild.id)) {
    await interaction.respond([]).catch(() => null);
    return true;
  }

  const query = String(interaction.options.getFocused(true)?.value ?? '').toLowerCase();
  const choices = guildConfig.panels
    .filter((panel) => panel.name.toLowerCase().includes(query) || panel.key.toLowerCase().includes(query))
    .slice(0, 25)
    .map((panel) => ({ name: panel.name, value: panel.key }));
  await interaction.respond(choices).catch(() => null);
  return true;
}

async function handleCommand(interaction) {
  if (!interaction.inGuild() || !interaction.guild || !(interaction.member instanceof GuildMember)) return;
  const guildConfig = getTicketGuildConfig(interaction.guild.id);
  const commandName = interaction.commandName;

  if (!guildConfig) {
    await interaction.reply({ content: 'Ticket system is not enabled in this server.', flags: 64 }).catch(() => null);
    return;
  }

  if (commandName === 'ticketpanel') {
    await handleTicketPanelCommand(interaction);
    return;
  }

  if (!memberCanUseTicketCommands(interaction.member, interaction.guild.id)) {
    await interaction.reply({ content: 'You do not have permission to use this command.', flags: 64 }).catch(() => null);
    return;
  }

  const channel = interaction.channel;
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: 'This command must be used inside a ticket channel.', flags: 64 }).catch(() => null);
    return;
  }

  const tickets = await getTicketsCollection();
  const ticket = await tickets.findOne({ guildId: interaction.guild.id, channelId: channel.id });
  if (!ticket) {
    await interaction.reply({ content: 'This channel is not a ticket.', flags: 64 }).catch(() => null);
    return;
  }

  if (commandName === 'add' || commandName === 'remove') {
    const user = interaction.options.getUser('user', false);
    const role = interaction.options.getRole('role', false);
    if (!user && !role) {
      await interaction.reply({ content: 'Provide either a user or a role.', flags: 64 }).catch(() => null);
      return;
    }
    const targetId = user?.id ?? role.id;
    const isRole = !!role;

    if (commandName === 'add') {
      await channel.permissionOverwrites
        .edit(targetId, {
          ViewChannel: true,
          SendMessages: true,
          ReadMessageHistory: true,
          AttachFiles: true,
          EmbedLinks: true,
        })
        .catch(() => null);
      await tickets
        .updateOne(
          { guildId: interaction.guild.id, channelId: channel.id },
          isRole ? { $addToSet: { extraRoleIds: targetId } } : { $addToSet: { extraMemberIds: targetId } },
        )
        .catch(() => null);
      await interaction
        .reply({
          content: isRole ? `Added <@&${targetId}> to this ticket.` : `Added <@${targetId}> to this ticket.`,
          flags: 64,
          allowedMentions: { parse: [] },
        })
        .catch(() => null);
      return;
    }

    await channel.permissionOverwrites.delete(targetId).catch(() => null);
    await tickets
      .updateOne(
        { guildId: interaction.guild.id, channelId: channel.id },
        isRole ? { $pull: { extraRoleIds: targetId } } : { $pull: { extraMemberIds: targetId } },
      )
      .catch(() => null);
    await interaction
      .reply({
        content: isRole ? `Removed <@&${targetId}> from this ticket.` : `Removed <@${targetId}> from this ticket.`,
        flags: 64,
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
    return;
  }

  if (commandName === 'claim') {
    if (ticket.claimedBy) {
      await interaction.reply({ content: 'This ticket is already claimed.', flags: 64 }).catch(() => null);
      return;
    }
    await tickets
      .updateOne({ guildId: interaction.guild.id, channelId: channel.id }, { $set: { claimedBy: interaction.user.id, claimStatus: 'claimed' } })
      .catch(() => null);
    await updateOpenMessageButtons(channel, ticket.openMessageId, buildClaimedButtons());
    await interaction.reply({ content: `Ticket claimed by <@${interaction.user.id}>.`, flags: 64, allowedMentions: { parse: [] } }).catch(() => null);
    return;
  }

  if (commandName === 'unclaim') {
    if (!ticket.claimedBy) {
      await interaction.reply({ content: 'This ticket is not claimed.', flags: 64 }).catch(() => null);
      return;
    }
    const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
    if (ticket.claimedBy !== interaction.user.id && !isAdmin) {
      await interaction.reply({ content: `You can't unclaim a ticket you didn't claim.`, flags: 64 }).catch(() => null);
      return;
    }
    await tickets
      .updateOne({ guildId: interaction.guild.id, channelId: channel.id }, { $set: { claimedBy: null, claimStatus: 'unclaimed' } })
      .catch(() => null);
    await updateOpenMessageButtons(channel, ticket.openMessageId, buildOpenButtons());
    await interaction
      .reply({
        content: isAdmin && ticket.claimedBy !== interaction.user.id ? 'Ticket unclaimed (admin override).' : 'Ticket unclaimed.',
        flags: 64,
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
    return;
  }

  if (commandName === 'close') {
    const reason = interaction.options.getString('reason', true).trim() || 'No reason provided.';
    await interaction.reply({ content: 'Closing this ticket...', flags: 64 }).catch(() => null);
    await closeTicketByChannel({
      guildId: interaction.guild.id,
      channelId: channel.id,
      closedByUserId: interaction.user.id,
      closeReason: reason,
      client: interaction.client,
    });
    return;
  }

  if (commandName === 'closerequest') {
    const reason = interaction.options.getString('reason', true).trim() || 'No reason provided.';
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(TICKET_CLOSE_REQUEST_ACCEPT_BUTTON_ID).setLabel('Close Ticket').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(TICKET_CLOSE_REQUEST_DENY_BUTTON_ID).setLabel('Keep Open').setStyle(ButtonStyle.Secondary),
    );
    const embed = new EmbedBuilder()
      .setColor('#242429')
      .setTitle('Close Request')
      .setDescription(`A staff member is requesting to close this ticket.\n\n**Reason:** ${reason}`);
    const message = await channel
      .send({
        content: `<@${ticket.userId}>`,
        embeds: [embed],
        components: [row],
      })
      .catch(() => null);
    if (message) {
      await tickets
        .updateOne(
          { guildId: interaction.guild.id, channelId: channel.id },
          { $set: { closeRequest: { requestedBy: interaction.user.id, reason, requestedAt: Date.now(), messageId: message.id } } },
        )
        .catch(() => null);
    }
    await interaction.reply({ content: 'Close request sent.', flags: 64 }).catch(() => null);
    return;
  }

  if (commandName === 'rename') {
    const newName = interaction.options.getString('name', true).trim();
    await channel.setName(newName).catch(() => null);
    await interaction.reply({ content: `Renamed this ticket to **${newName}**.`, flags: 64 }).catch(() => null);
    return;
  }

  if (commandName === 'switchpanel') {
    const previousPanelName = ticket.panelName ?? 'Unknown';
    const panelKey = interaction.options.getString('panel', true);
    const panel = getTicketPanelByKey(interaction.guild.id, panelKey);
    if (!panel) {
      await interaction.reply({ content: 'Invalid panel for this server.', flags: 64 }).catch(() => null);
      return;
    }
    const category = await interaction.guild.channels.fetch(panel.categoryId).catch(() => null);
    if (!category || category.type !== ChannelType.GuildCategory) {
      await interaction.reply({ content: 'Target category is invalid or missing.', flags: 64 }).catch(() => null);
      return;
    }
    const visibleSupportRoleIds = getVisibleSupportRoleIdsForPanel(interaction.guild.id, panel.key);
    await channel.setParent(category.id, { lockPermissions: false }).catch(() => null);
    await channel
      .permissionOverwrites.set(
        buildPermissionOverwrites({
          guild: interaction.guild,
          ticket,
          visibleSupportRoleIds,
        }),
      )
      .catch(() => null);
    await tickets
      .updateOne({ guildId: interaction.guild.id, channelId: channel.id }, { $set: { panelKey: panel.key, panelName: panel.name } })
      .catch(() => null);
    if (typeof ticket.ticketNumber === 'number' && ticket.ticketNumber > 0) {
      const newName = renderChannelName(guildConfig.channelNameTemplate, {
        panel: panel.channelSlug ?? panel.key,
        number: ticket.ticketNumber,
        username: ticket.username ?? 'ticket',
      });
      await channel.setName(newName).catch(() => null);
    }
    await interaction
      .reply({
        content: `Ticket panel switched: **${previousPanelName}** → **${panel.name}**.`,
        flags: 64,
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
  }
}

async function handleButton(interaction) {
  if (!interaction.guild || !(interaction.member instanceof GuildMember)) return false;
  if (!getTicketGuildConfig(interaction.guild.id)) return false;

  const id = interaction.customId;
  if (id.startsWith(TICKET_TRANSCRIPT_REQUEST_BUTTON_PREFIX)) {
    const ticketChannelId = id.slice(TICKET_TRANSCRIPT_REQUEST_BUTTON_PREFIX.length).trim();
    if (!ticketChannelId) return false;

    const tickets = await getTicketsCollection();
    const ticket = await tickets.findOne({ guildId: interaction.guild.id, channelId: ticketChannelId });
    if (!ticket) {
      await interaction.reply({ content: 'Ticket not found in the database.', flags: 64 }).catch(() => null);
      return true;
    }
    if (!memberCanViewTranscript({ member: interaction.member, ticket })) {
      await interaction.reply({ content: 'You do not have permission to view this transcript.', flags: 64 }).catch(() => null);
      return true;
    }
    if (!ticket.transcriptUrl) {
      await interaction.reply({ content: 'No transcript is available for this ticket.', flags: 64 }).catch(() => null);
      return true;
    }
    await interaction
      .reply({
        content: `Transcript for ${renderChannelName('ticket-{panel}-{number}', {
          panel: getTicketPanelByKey(interaction.guild.id, ticket.panelKey)?.channelSlug ?? ticket.panelKey,
          number: ticket.ticketNumber,
          username: ticket.username ?? 'ticket',
        })}`,
        components: [buildTranscriptLinkRow(ticket.transcriptUrl)],
        flags: 64,
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
    return true;
  }

  if (
    id !== TICKET_CLAIM_BUTTON_ID &&
    id !== TICKET_UNCLAIM_BUTTON_ID &&
    id !== TICKET_CLOSE_BUTTON_ID &&
    id !== TICKET_CLOSE_REQUEST_ACCEPT_BUTTON_ID &&
    id !== TICKET_CLOSE_REQUEST_DENY_BUTTON_ID
  ) {
    return false;
  }

  const channel = interaction.channel;
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: 'This action must be used inside a ticket channel.', flags: 64 }).catch(() => null);
    return true;
  }

  const tickets = await getTicketsCollection();
  const ticket = await tickets.findOne({ guildId: interaction.guild.id, channelId: channel.id });
  if (!ticket) {
    await interaction.reply({ content: 'Ticket not found in the database.', flags: 64 }).catch(() => null);
    return true;
  }

  if (id === TICKET_CLOSE_REQUEST_ACCEPT_BUTTON_ID || id === TICKET_CLOSE_REQUEST_DENY_BUTTON_ID) {
    if (interaction.user.id !== ticket.userId) {
      await interaction.reply({ content: 'Only the ticket opener can respond to a close request.', flags: 64 }).catch(() => null);
      return true;
    }
    if (!ticket.closeRequest) {
      await interaction.reply({ content: 'There is no close request for this ticket.', flags: 64 }).catch(() => null);
      return true;
    }

    if (id === TICKET_CLOSE_REQUEST_DENY_BUTTON_ID) {
      await tickets.updateOne({ guildId: interaction.guild.id, channelId: channel.id }, { $unset: { closeRequest: '' } }).catch(() => null);
      await interaction.update({ components: [] }).catch(() => null);
      await channel.send({ embeds: [new EmbedBuilder().setColor('#242429').setDescription('Close request denied. This ticket will remain open.')] }).catch(() => null);
      return true;
    }

    await interaction.update({ components: [] }).catch(() => null);
    await closeTicketByChannel({
      guildId: interaction.guild.id,
      channelId: channel.id,
      closedByUserId: interaction.user.id,
      closeReason: ticket.closeRequest.reason || 'No reason provided.',
      client: interaction.client,
    });
    return true;
  }

  if (id === TICKET_CLOSE_BUTTON_ID) {
    if (!memberCanUseTicketCommands(interaction.member, interaction.guild.id)) {
      await interaction.reply({ content: 'You do not have permission to close tickets.', flags: 64 }).catch(() => null);
      return true;
    }
    const modal = ModalBuilder.from({
      custom_id: TICKET_CLOSE_MODAL_ID,
      title: 'Close Ticket',
      components: [
        {
          type: ComponentType.Label,
          label: 'Reason for closing the ticket',
          component: {
            type: ComponentType.TextInput,
            custom_id: TICKET_CLOSE_REASON_INPUT_ID,
            style: TextInputStyle.Paragraph,
            placeholder: 'Enter the reason here...',
            required: false,
          },
        },
      ],
    });
    await interaction.showModal(modal).catch(() => null);
    return true;
  }

  if (id === TICKET_CLAIM_BUTTON_ID) {
    if (!memberCanUseTicketCommands(interaction.member, interaction.guild.id)) {
      await interaction.reply({ content: 'You do not have permission to claim tickets.', flags: 64 }).catch(() => null);
      return true;
    }
    if (ticket.claimedBy) {
      await interaction.reply({ content: 'This ticket is already claimed.', flags: 64 }).catch(() => null);
      return true;
    }
    await tickets
      .updateOne({ guildId: interaction.guild.id, channelId: channel.id }, { $set: { claimedBy: interaction.user.id, claimStatus: 'claimed' } })
      .catch(() => null);
    const containers = getContainersFromMessageComponents(interaction.message.components);
    await interaction
      .update({
        components: [...containers, buildClaimedButtons().toJSON()],
        flags: MessageFlags.IsComponentsV2,
      })
      .catch(() => null);
    await channel
      .send({
        embeds: [new EmbedBuilder().setDescription(`This ticket has been claimed by <@${interaction.user.id}>.`).setColor('#242429')],
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
    return true;
  }

  if (id === TICKET_UNCLAIM_BUTTON_ID) {
    if (ticket.claimedBy !== interaction.user.id) {
      await interaction.reply({ content: `You can't unclaim a ticket you didn't claim.`, flags: 64 }).catch(() => null);
      return true;
    }
    await tickets
      .updateOne({ guildId: interaction.guild.id, channelId: channel.id }, { $set: { claimedBy: null, claimStatus: 'unclaimed' } })
      .catch(() => null);
    const containers = getContainersFromMessageComponents(interaction.message.components);
    await interaction
      .update({
        components: [...containers, buildOpenButtons().toJSON()],
        flags: MessageFlags.IsComponentsV2,
      })
      .catch(() => null);
    await channel
      .send({
        embeds: [new EmbedBuilder().setDescription('This ticket has been unclaimed.').setColor('#242429')],
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
    return true;
  }

  return false;
}

const moduleDef = {
  id: 'ticketSystem',
  requiredIntents: ['Guilds', 'GuildMembers', 'GuildPresences'],
  slashCommands: buildSlashCommands(),
  enabled: (ctx) => {
    if (!config.enabled) return false;
    if (!Object.keys(config.guilds).length) return false;
    if (!env.mongoUri) {
      ctx.logger.warn('Ticket system disabled: MONGODB_URI is not set.');
      return false;
    }
    if (config.accountLinkProvider === 'dock' && !env.dockApiKey) {
      ctx.logger.warn('Ticket system disabled: accountLinkProvider is "dock" but DOCK_API_KEY is not set.');
      return false;
    }
    if (config.accountLinkProvider === 'melonly' && !env.melonlyApiKey) {
      ctx.logger.warn('Ticket system disabled: accountLinkProvider is "melonly" but MELONLY_API_KEY is not set.');
      return false;
    }
    return true;
  },
  init: async (ctx) => {
    await Promise.all([getTicketsCollection(), getCountersCollection()]).catch((err) => {
      throw new Error(`Failed initializing ticket system collections: ${err?.message || String(err)}`);
    });

    const onInteractionCreate = async (interaction) => {
      if (interaction.isAutocomplete() && interaction.commandName === 'switchpanel') {
        await handleSwitchPanelAutocomplete(interaction);
        return;
      }
      if (interaction.isChatInputCommand()) {
        await handleCommand(interaction);
        return;
      }
      if (interaction.isStringSelectMenu()) {
        const handled = await handleSelect(interaction);
        if (handled) return;
      }
      if (interaction.isModalSubmit()) {
        const handledClose = await handleCloseModal(interaction);
        if (handledClose) return;
        await handleTicketCreateModal(interaction);
        return;
      }
      if (interaction.isButton()) {
        await handleButton(interaction);
      }
    };

    return {
      events: {
        ready: () => {
          ctx.logger.info('Ticket system module ready.');
        },
        interactionCreate: (interaction) => {
          onInteractionCreate(interaction).catch((err) => {
            ctx.logger.warn(`Ticket system interaction failed: ${err?.message || String(err)}`);
          });
        },
      },
    };
  },
};

module.exports = moduleDef;
